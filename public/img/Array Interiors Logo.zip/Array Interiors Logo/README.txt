AR Symbol - Vector
"Array Interiors" - Text used - Acumin Variable Concept - Regular